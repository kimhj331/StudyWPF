﻿using System.Windows.Controls;

namespace BikeShop
{
    /// <summary>
    /// Contact.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class Discussion : Page
    {
        public Discussion()
        {
            InitializeComponent();
        }

        private void Page_Loaded(object sender, System.Windows.RoutedEventArgs e)
        {

        }

        private void Grid_Loaded(object sender, System.Windows.RoutedEventArgs e)
        {

        }
    }
}
